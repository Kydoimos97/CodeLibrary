from setuptools import setup, find_packages

VERSION = '0.0.2'
DESCRIPTION = 'Reusable Code Library'

# Setting up
setup(
    name="CodeLib",
    version=VERSION,
    packages=find_packages())